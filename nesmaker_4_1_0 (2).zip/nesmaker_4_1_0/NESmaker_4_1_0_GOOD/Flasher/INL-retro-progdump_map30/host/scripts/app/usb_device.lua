-- info used to open usb device
libusb_log = 0	-- 0: default no msg printing, 1: errors, 2: warnings, 3: info, 4: debug
