libusb .a files are copied from libusb v1.0.20 MinGW32 folders.

libusb-1.0.dll file from MinGW32 copied to base dir with executable must be present to run program.
