libusb copied from libusb v1.0.20 include folder.

dgb.h from Zed Shaw's Learn C the Hard Way book/github:
https://github.com/zedshaw/learn-c-the-hard-way-lectures
