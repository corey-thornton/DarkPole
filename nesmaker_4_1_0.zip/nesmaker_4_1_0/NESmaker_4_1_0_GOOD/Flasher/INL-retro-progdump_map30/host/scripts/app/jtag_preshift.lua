
-- create the module's table
local jtag = {}

-- import required modules
local dict = require "scripts.app.dict"

-- file constants
local pbje_loc	--physical location of PBJE engine so this script known how to set engine registers
local cur_jtag_state

-- local functions

-- initialize lua portions of JTAG
-- JTAG hardware port may be virtuatlized by placing PBJE "Paul's Basic JTAG Engine" 
-- inside the board itself (ie CIC mcu) instead of on the inlretro programmer
-- in these types of cases, want the jtag high level functions to be independent of
-- where the PBJE engine is located physically.
local function init_jtag_lua( location )

	pbje_loc = location

end

local function wait_pbje_done( num_polls, debug )

	local status

	while( num_polls > 0 ) do

		status = dict.jtag("GET_STATUS") 
		if( status == op_jtag["PBJE_DONE"]) then
			if( debug) then print("PBJE done num polls left:", num_polls) end
			return true
		else
			if( debug) then print("PBJE wasn't done, status:", status) end
		end
		num_polls = num_polls - 1
	end

	print("JTAG timed out while waiting for PBJE_DONE")
	return false

end

local function set_data_2B( data )

	--check args
	if( data > 0xFFFF  )then
		print("ERROR data:", data, "too large for set_data_2B")
		return false
	end

	--set data based on pjbe location
	if( pbje_loc == nil ) then
		print("ERROR, pbje location must be initialized prior to setting registers")

	elseif( pbje_loc == "INLRETRO" ) then
		dict.jtag("SET_2B_DATA", data)
		return true

	else 
		print("ERROR, pbje location:", pbje_loc, "not recognized by set_data_2B function.")
	end

	--failed if got to this point without returning
	return false

end

local function set_clk( num_clks )

	--check args
	if( num_clks == 256 ) then
		num_clks = 0
	elseif( num_clks > 255 or num_clks < 0  )then
		print("ERROR num clks:", num_clks, "exceeds range of 1-256")
		return false
	end

	--set num_clks based on pjbe location
	if( pbje_loc == nil ) then
		print("ERROR, pbje location must be initialized prior to setting registers")

	elseif( pbje_loc == "INLRETRO" ) then
		dict.jtag("SET_NUMCLK", num_clks)
		return true

	else 
		print("ERROR, pbje location:", pbje_loc, "not recognized by set_clk function.")
	end

	--failed if got to this point without returning
	return false

end

local function set_run_get_cmd( command )

	local rv

	--check args
	if not op_jtag[command] then
		print("ERROR command:", command, "is not defined in shared_dict_jtag.h")
		return false
	end

	--set command based on pjbe location
	if( pbje_loc == nil ) then
		print("ERROR, pbje location must be initialized prior to setting registers")

	elseif( pbje_loc == "INLRETRO" ) then
		rv = dict.jtag("SET_CMD_WAIT", command)
		--verify command was done
		if(rv ~= op_jtag["PBJE_DONE"]) then print("error JTAG not done, status: ", rv) end
		return true

	else 
		print("ERROR, pbje location:", pbje_loc, "not recognized by set_run_get_command function.")
	end

	--failed if got to this point without returning
	return false

end

-- clocks JTAG statemachine with TMS set to 1 enough times to guarantee RESET state
-- prereq: JTAG PBJEngine must be initialized
local function reset_statemachine( debug )

	local rv
	--only takes 5 clocks with TMS high to force into RESET from any state
	set_clk(8)
	set_run_get_cmd("PBJE_CLOCK1")	--no data needed for this opcode, forces TMS to 1

	--we know the state machine is in RESET now
	cur_jtag_state = "RESET"
end


local function state_RESET_to_SHIFTDR()
	--reset-DRshift c4 m0010
	set_data_2B(0x0002)
	set_clk(4)
	set_run_get_cmd("PBJE_STATE_CHG")

end

-- current and next JTAG state must be stable (RESET, IDLE, PAUSE-DR/IR) or SHIFT-DR/IR
-- only exception is reset will blindly force RESET by clocking with TMS high
-- other gotcha is that the first TDI is latched on same TCK rising edge that puts
-- statemachine in SHIFT-DR/IR, so going to SHIFT is really going to state just prior;
-- then the next TCK posedge with TMS low will be first SHIFT-IR/DR cycle
-- so this function actually goes to PRE_SHIFT-IR/DR
-- the scan in/out subsequent step will put in SHIFT-IR/DR state

local function goto_state( new_jtag_state )

	local clk, tms, next_jtag_state

	--if new state is RESET then, just blindly clock with TMS high
	if( new_jtag_state == "RESET" ) then
		reset_statemachine()
		return true
	end

	--current state is stored in cur_jtag_state
	if( cur_jtag_state == "RESET" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 1
			tms = 0	-- IDLE-RESET
			next_jtag_state = "IDLE"

		elseif( new_jtag_state == "PRESHIFT_DR" ) then
			--clk = 4
			--tms = 0x02 -- SHIFT-CAP-SELDR-IDLE 0010
			clk = 3
			tms = 0x02 -- CAP-SELDR-IDLE 010
			next_jtag_state = "PRESHIFT_DR"


		elseif( new_jtag_state == "PRESHIFT_IR" ) then
			--clk = 5
			--tms = 0x06 -- SHIFT-CAP-SELIR-SELDR-IDLE 00110
			clk = 4
			tms = 0x06 -- CAP-SELIR-SELDR-IDLE 0110
			next_jtag_state = "PRESHIFT_IR"


		elseif( new_jtag_state == "PAUSE_DR" ) then
			clk = 5
			tms = 0x0a -- PAUSE-EX1-CAP-SELDR-IDLE 01010
			next_jtag_state = "PAUSE_DR"


		elseif( new_jtag_state == "PAUSE_IR" ) then
			clk = 6
			tms = 0x16 -- PAUSE-EX1-CAP-SELIR-SELDR-IDLE 010110
			next_jtag_state = "PAUSE_IR"

		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor shift state!!!")
			return nil
		end
			

	elseif( cur_jtag_state == "IDLE" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 1
			tms = 0	-- IDLE-IDLE
			next_jtag_state = "IDLE"

		elseif( new_jtag_state == "PRESHIFT_DR" ) then
			--clk = 3
			--tms = 0x01 -- SHIFT-CAP-SELDR 001
			clk = 2
			tms = 0x01 -- CAP-SELDR 01
			next_jtag_state = "PRESHIFT_DR"

		elseif( new_jtag_state == "PRESHIFT_IR" ) then
			--clk = 4
			--tms = 0x03 -- SHIFT-CAP-SELIR-SELDR 0011
			clk = 3
			tms = 0x03 -- CAP-SELIR-SELDR 011
			next_jtag_state = "PRESHIFT_IR"

		elseif( new_jtag_state == "PAUSE_DR" ) then
			clk = 4
			tms = 0x05 -- PAUSE-EX1-CAP-SELDR 0101
			next_jtag_state = "PAUSE_DR"

		elseif( new_jtag_state == "PAUSE_IR" ) then
			clk = 5
			tms = 0x0b -- PAUSE-EX1-CAP-SELIR-SELDR 01011
			next_jtag_state = "PAUSE_IR"
		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor shift state!!!")
			return nil
		end

	elseif( cur_jtag_state == "SHIFT_DR" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 3
			tms = 0x03 -- IDLE-UP-EX1 011
			next_jtag_state = "IDLE"

	--	elseif( new_jtag_state == "SHIFT_DR" ) then
	--		--nothing to do
	--		return true

		elseif( new_jtag_state == "PRESHIFT_IR" ) then
			--clk = 6
			--tms = 0x0f -- SHIFT-CAP-SELIR-SELDR-UP-EX1 00_1111
			clk = 5
			tms = 0x0f -- CAP-SELIR-SELDR-UP-EX1 0_1111
			next_jtag_state = "PRESHIFT_IR"

		elseif( new_jtag_state == "PAUSE_DR" ) then
			clk = 2
			tms = 0x01 -- PAUSE-EX1 01
			next_jtag_state = "PAUSE_DR"

		elseif( new_jtag_state == "PAUSE_IR" ) then
			clk = 7
			tms = 0x2f -- PAUSE-EX1-CAP-SELIR-SELDR-UP-EX1 010_1111
			next_jtag_state = "PAUSE_IR"
		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor pre-shift state!!!")
			return nil
		end

	elseif( cur_jtag_state == "SHIFT_IR" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 3
			tms = 0x03 -- IDLE-UP-EX1 011
			next_jtag_state = "IDLE"

		elseif( new_jtag_state == "PRESHIFT_DR" ) then
			--clk = 5
			--tms = 0x07 -- SHIFT-CAP-SELIR-UP-EX1 0_0111
			clk = 4
			tms = 0x07 -- CAP-SELIR-UP-EX1 0111
			next_jtag_state = "PRESHIFT_DR"

	--	elseif( new_jtag_state == "SHIFT_IR" ) then
	--		--nothing to do
	--		return true

		elseif( new_jtag_state == "PAUSE_DR" ) then
			clk = 6
			tms = 0x17 -- PAUSE-EX1-CAP-SELIR-UP-EX1 01_0111
			next_jtag_state = "PAUSE_DR"

		elseif( new_jtag_state == "PAUSE_IR" ) then
			clk = 2
			tms = 0x01 -- PAUSE-EX1 01
			next_jtag_state = "PAUSE_IR"
		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor pre-shift state!!!")
			return nil
		end

	elseif( cur_jtag_state == "PAUSE_DR" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 3
			tms = 0x03 -- IDLE-UP-EX2 011
			next_jtag_state = "IDLE"

		elseif( new_jtag_state == "PRESHIFT_DR" ) then
			--clk = 2
			--tms = 0x01 -- SHIFT-EX2 01
			clk = 1
			tms = 0x01 -- EX2 1
			next_jtag_state = "PRESHIFT_DR"

		elseif( new_jtag_state == "PRESHIFT_IR" ) then
			--clk = 6
			--tms = 0x0f -- SHIFT-CAP-SELIR-SELDR-UP-EX2 00_1111
			clk = 5
			tms = 0x0f -- CAP-SELIR-SELDR-UP-EX2 0_1111
			next_jtag_state = "PRESHIFT_IR"

		elseif( new_jtag_state == "PAUSE_DR" ) then
			--nothing to do
			return true

		elseif( new_jtag_state == "PAUSE_IR" ) then
			clk = 7
			tms = 0x2f -- PAUSE-EX1-CAP-SELIR-SELDR-UP_EX2 010_1111
			next_jtag_state = "PAUSE_IR"
		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor pre-shift state!!!")
			return nil
		end

	elseif( cur_jtag_state == "PAUSE_IR" ) then
		if( new_jtag_state == "IDLE" ) then
			clk = 3
			tms = 0x03 -- IDLE-UP-EX2 011
			next_jtag_state = "IDLE"

		elseif( new_jtag_state == "PRESHIFT_DR" ) then
			--clk = 5
			--tms = 0x07 -- SHIFT-CAP-SELDR-UP-EX2 0_0111
			clk = 4
			tms = 0x07 -- CAP-SELDR-UP-EX2 0111
			next_jtag_state = "PRESHIFT_DR"

		elseif( new_jtag_state == "PRESHIFT_IR" ) then
			--clk = 2
			--tms = 0x01 -- SHIFT-EX2 01
			clk = 1
			tms = 0x01 -- EX2 1
			next_jtag_state = "PRESHIFT_IR"

		elseif( new_jtag_state == "PAUSE_DR" ) then
			clk = 6
			tms = 0x17 -- PAUSE-EX1-CAP-SELDR-UP_EX2 01_0111
			next_jtag_state = "PAUSE_DR"

		elseif( new_jtag_state == "PAUSE_IR" ) then
			--nothing to do
			return true
		else
			print("ERROR!!!  new JTAG state:", new_jtag_state, "isn't stable, nor pre-shift state!!!")
			return nil
		end



	else
		print("ERROR!!!  current JTAG state:", cur_jtag_state, "isn't stable, nor shift state!!!")
		return nil
	end

	--set PJBE register values and give state change command
	set_data_2B(tms)
	set_clk(clk)
	set_run_get_cmd("PBJE_STATE_CHG")
	cur_jtag_state = next_jtag_state
	return true

end



local function run_jtag( debug )

	--setup lua portion of jtag engine
	init_jtag_lua("INLRETRO")

	--initialize JTAG port on USB device
	dict.io("JTAG_INIT", "JTAG_ON_EXP0_3")

	--first put/verify jtag statemachine is in RESET
	goto_state("RESET")

	--by default jtag should be in IDCODE or BYPASS if IDCODE not present
	
	--change to SCAN-DR state
	goto_state("PRESHIFT_DR")

	--scan out 32bit IDCODE while scanning in 1's to TDI
	dict.jtag("SET_NUMCLK", 32)
	dict.jtag("SET_CMD", "PBJE_TDO_SCAN1")
	cur_jtag_state = "SHIFT_DR"
	--verify done before updating PBJE values
	jtag.wait_pbje_done( 4, true )

	rv = dict.jtag("GET_6B_DATA")
	print("return data:", string.format(" %X, ",rv))
	if( rv == 0x1281043 ) then
	-- Mach XO 256   01281043
	-- 4032v	(01805043)
	-- 4064v	(01809043)
	--
	-- 9536xl
	-- //Loading device with 'idcode' instruction.
	-- SIR 8 TDI (fe) SMASK (ff) ;
	-- SDR 32 TDI (00000000) SMASK (ffffffff) TDO (f9602093) MASK (0fffffff) ;
	--
	-- 9572xl
	-- //Loading device with 'idcode' instruction.
	-- SIR 8 TDI (fe) SMASK (ff) ;
	-- SDR 32 TDI (00000000) SMASK (ffffffff) TDO (f9604093) MASK (0fffffff) ;
	-- test read gives 59604093
		print("IDCODE matches MACHXO-256")
	else
		print("no match for IDCODE")
	end
	
	--Mach XO verify ID code
--	! Check the IDCODE
--
--	! Shift in IDCODE(0x16) instruction
--	SIR     8       TDI  (16);
	goto_state("PRESHIFT_IR")
	set_data_2B(0x2C)
	set_clk(8)
	set_run_get_cmd("PBJE_TDI_SCAN")
	cur_jtag_state = "SHIFT_IR"
	goto_state("PAUSE_IR")

--	SDR     32      TDI  (FFFFFFFF)
	goto_state("PRESHIFT_DR")
	set_clk(32)
	set_run_get_cmd("PBJE_TDO_SCAN1")
	cur_jtag_state = "SHIFT_DR"
	rv = dict.jtag("GET_6B_DATA")
	print("return data:", string.format(" %X, ",rv))
--	                TDO  (01281043)
--	                MASK (FFFFFFFF);
	
--	--change to SCAN-IR state
--	dict.jtag("SET_2B_DATA", 0x0006)
--	dict.jtag("SET_NUMCLK", 5)
--	dict.jtag("SET_CMD", "PBJE_STATE_CHG")
--	--verify done before updating PBJE values
--	jtag.wait_pbje_done( 4, true )
--
--	--scan in IDCODE instruction
--	dict.jtag("SET_2B_DATA", 0x0016)
--	dict.jtag("SET_NUMCLK", 8)
--	dict.jtag("SET_CMD", "PBJE_TDI_SCAN")
--	--verify done before updating PBJE values
--	jtag.wait_pbje_done( 4, true )
--
--	--change to SCAN-DR state
--	--shift-pause c2 m01
--	--IRpause-DRshift c5 m00111
--	--together c7 m001_1101 -> 0x1D
--	dict.jtag("SET_2B_DATA", 0x001D)
--	dict.jtag("SET_NUMCLK", 7)
--	dict.jtag("SET_CMD", "PBJE_STATE_CHG")
--	--verify done before updating PBJE values
--	jtag.wait_pbje_done( 4, true )
--
--
--	--scan out 32bit IDCODE while scanning in 1's to TDI
--	dict.jtag("SET_NUMCLK", 32)
--	dict.jtag("SET_CMD", "PBJE_TDO_SCAN1")
--	--verify done before updating PBJE values
--	jtag.wait_pbje_done( 4, true )
--
--	print("return data:", dict.jtag("GET_6B_DATA"))

end

-- global variables so other modules can use them


-- call functions desired to run when script is called/imported


-- functions other modules are able to call
jtag.wait_pbje_done = wait_pbje_done
jtag.run_jtag = run_jtag

-- return the module's table
return jtag
